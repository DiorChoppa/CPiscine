#ifndef FT_STR_H
# define FT_STR_H

void	ft_str_write_to(int fd, char *str);
void	ft_str_write(char *str);

#endif
