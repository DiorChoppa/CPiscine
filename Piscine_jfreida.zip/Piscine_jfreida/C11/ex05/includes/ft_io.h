#ifndef FT_IO_H
# define FT_IO_H

# define IN 0
# define OUT 1
# define ERR 2

#endif
