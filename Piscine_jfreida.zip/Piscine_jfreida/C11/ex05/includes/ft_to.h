#ifndef FT_TO_H
# define FT_TO_H

int		ft_atoi(char *str);

#endif
