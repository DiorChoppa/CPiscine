#ifndef FT_IS_H
# define FT_IS_H

# include "ft_boolean.h"

t_bool	ft_is_number(char c);

t_bool	ft_is_whitespace(char c);

#endif
