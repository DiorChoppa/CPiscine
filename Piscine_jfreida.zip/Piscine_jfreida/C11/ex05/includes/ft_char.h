#ifndef FT_CHAR_H
# define FT_CHAR_H

void	ft_char_write_to(int fd, char c);
void	ft_char_write(char c);

#endif
