#ifndef FT_NUMBER_H
# define FT_NUMBER_H

void	ft_number_write(int number);

#endif
