#ifndef FT_EQUAL_H
# define FT_EQUAL_H

# include <stdbool.h>

bool	ft_is_equal(char *a, char *b, unsigned int size);

#endif
