#ifndef FT_ATOI_H
# define FT_ATOI_H

int		ft_abs_strict_atoi(char *str);

#endif
