#ifndef FT_STRNCPY_H
# define FT_STRNCPY_H

char	*ft_str_sized_copy(char *dest, char *src, unsigned int src_size);

#endif
