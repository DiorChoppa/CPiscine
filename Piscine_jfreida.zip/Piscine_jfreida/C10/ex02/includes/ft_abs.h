#ifndef FT_ABS_H
# define FT_ABS_H

unsigned int ft_abs_int (int number);

#endif
