export FT_USER=root

./print_groups.sh

export FT_USER=daemon

./print_groups.sh
