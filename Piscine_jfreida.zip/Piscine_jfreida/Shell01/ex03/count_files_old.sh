find . -type f | wc -l | tr -d ' '
