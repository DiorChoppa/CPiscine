#!/bin/bash
for i in {1..20}
do
   touch "dummy_$i"
done
